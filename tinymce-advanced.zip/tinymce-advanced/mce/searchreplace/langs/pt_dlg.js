tinyMCE.addI18n('pt.searchreplace_dlg',{
searchnext_desc:"Localizar novamente",
notfound:"Pesquisa conclu\u00EDda sem resultados.",
search_title:"Localizar",
replace_title:"Localizar/substituir",
allreplaced:"Todas substitui\u00E7\u00F5es foram efetuadas.",
findwhat:"Localizar",
replacewith:"Substituir com",
direction:"Dire\u00E7\u00E3o",
up:"Acima",
down:"Abaixo",
mcase:"Diferenciar mai\u00FAsculas/min\u00FAsculas",
findnext:"Localizar o seguinte",
replace:"Substituir",
replaceall:"Substituir todos"
});