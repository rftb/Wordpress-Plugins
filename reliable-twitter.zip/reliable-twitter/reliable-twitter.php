<?php
/*
Plugin Name: Reliable Twitter
Plugin URI: http://www.soapboxdave.com/reliabletwitter/
Description: Adds a sidebar widget to display Twitter updates and uses the more-reliable Google AJAX API.
Version: 1.2
Author: David Hollander
Author URI: http://www.soapboxdave.com/
License: GPL

This software comes without any warranty, express or otherwise. Use at your own risk.

*/

function reliabletwitter($accountid, $show = 3, $title = '', $target = '_blank', $googleapikey = '') {
		echo '<div id="twitter_div">';
		if ($title) echo "<h4 id=\"reliabletwitter_title\">".__($title)."</h4>";
		echo '<ul id="twitter_update_list"></ul></div>';
		if ($googleapikey) $googleapikey = "?key=$googleapikey";
		echo '<script type="text/javascript" src="http://www.google.com/jsapi'.$googleapikey.'"></script>'."\n";
		echo '<script type="text/javascript">'."\n";
		echo 'var reliable_twitter_id = ' . $accountid . ";\n";
		echo 'var reliable_twitter_show = ' . $show . ";\n";
		echo 'var reliable_twitter_target = "' . $target . "\";\n";
		echo '</script>';
		echo '<script type="text/javascript" src="'. WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),"",plugin_basename(__FILE__)) .'reliable-twitter.js"></script>';
}


function widget_reliabletwitter_init() {

	if (!function_exists('register_sidebar_widget')) return;
	
	function widget_reliabletwitter($args) {

		// "$args is an array of strings that help widgets to conform to
		// the active theme: before_widget, before_title, after_widget,
		// and after_title are the array keys." - These are set up by the theme
		extract($args);

		// These are our own options
		$options = get_option('widget_reliabletwitter');
		$accountid = $options['accountid'];		// Your Twitter account id
		$title = $options['title'];			// Title in sidebar for widget
		$show = $options['show'];			// # of Updates to show
		$target = $options['target'];			// Target of Links
		$googleapikey = $options['googleapikey'];	// Google API Key
		$twitterusername = $options['twitterusername'];	// Twitter Username for Follow Me Link
		$followmetext = $options['followmetext'];	// Follow Me Text

		// Write the Widget
		echo $before_widget;
		echo '<div id="twitter_div">'.$before_title.__($title).$after_title;
		echo '<ul id="twitter_update_list"></ul>';
		if ($followmetext && $twitterusername) echo "<div id=\"twitter_followme\"><a href=\"http://twitter.com/$twitterusername\" target=\"$target\">$followmetext</a></div>";
		echo '</div>';
		echo $after_widget;

		// Write the JS Stuff
		if ($googleapikey) $googleapikey = "?key=$googleapikey";
		echo '<script type="text/javascript" src="http://www.google.com/jsapi'.$googleapikey.'"></script>';
		echo '<script type="text/javascript">';
		echo 'var reliable_twitter_id = ' . $accountid . ";\n";
		echo 'var reliable_twitter_show = ' . $show . ";\n";
		echo 'var reliable_twitter_target = "' . $target . "\";\n";
		echo '</script>';
		echo '<script type="text/javascript" src="'. WP_PLUGIN_URL.'/'.str_replace(basename( __FILE__),"",plugin_basename(__FILE__)) .'reliable-twitter.js"></script>';
	}

	// Settings form
	function widget_reliabletwitter_control() {

		// Get options
		$options = get_option('widget_reliabletwitter');
		// options exist? if not set defaults
		if ( !is_array($options) )
			$options = array('accountid'=>'', 'title'=>'Twitter Updates', 'show'=>'3', 'target'=>'_blank');

        // form posted?
		if ( $_POST['Twitter-submit'] ) {

			// Remember to sanitize and format use input appropriately.
			$options['accountid'] = strip_tags(stripslashes($_POST['Twitter-account']));
			$options['title'] = strip_tags(stripslashes($_POST['Twitter-title']));
			$options['show'] = strip_tags(stripslashes($_POST['Twitter-show']));
			$options['target'] = strip_tags(stripslashes($_POST['Twitter-target']));
			$options['googleapikey'] = strip_tags(stripslashes($_POST['Twitter-googleapikey']));
			$options['twitterusername'] = strip_tags(stripslashes($_POST['Twitter-twitterusername']));
			$options['followmetext'] = strip_tags(stripslashes($_POST['Twitter-followmetext']));
			update_option('widget_reliabletwitter', $options);
		}

		// Get options for form fields to show
		$accountid = htmlspecialchars($options['accountid'], ENT_QUOTES);
		$title = htmlspecialchars($options['title'], ENT_QUOTES);
		$show = htmlspecialchars($options['show'], ENT_QUOTES);
		$target = htmlspecialchars($options['target'], ENT_QUOTES);
		$googleapikey = htmlspecialchars($options['googleapikey'], ENT_QUOTES);
		$twitterusername = htmlspecialchars($options['twitterusername'], ENT_QUOTES);
		$followmetext = htmlspecialchars($options['followmetext'], ENT_QUOTES);

		// The form fields
		echo '<p style="text-align:right;">
				<label for="Twitter-account">' . __('Account ID#') . '
				<input style="width: 146px;" id="Twitter-account" name="Twitter-account" type="text" value="'.$accountid.'" />
				<span style="font-size: 10px;">(<a href="http://www.idfromuser.com/" target="_blank">Lookup</a>)</span>
				</label></p>';
		echo '<p style="text-align:right;">
				<label for="Twitter-title">' . __('Title:') . '
				<input style="width: 200px;" id="Twitter-title" name="Twitter-title" type="text" value="'.$title.'" />
				</label></p>';
		echo '<p style="text-align:right;">
				<label for="Twitter-show">' . __('Show:') . '
				<input style="width: 200px;" id="Twitter-show" name="Twitter-show" type="text" value="'.$show.'" />
				</label></p>';
		echo '<p style="text-align:right;">
				<label for="Twitter-target">' . __('Link Target:') . '
				<input style="width: 200px;" id="Twitter-target" name="Twitter-target" type="text" value="'.$target.'" />
				</label></p>';
		echo '<p style="text-align:right;">
				<label for="Twitter-followmetext">' . __('Follow Me Text:') . '
				<input style="width: 141px;" id="Twitter-followmetext" name="Twitter-followmetext" type="text" value="'.$followmetext.'" />
				<span style="font-size: 10px;">(optional)</span>
				</label></p>';
		echo '<p style="text-align:right;">
				<label for="Twitter-twitterusername">' . __('Twitter Username:') . '
				<input style="width: 147px;" id="Twitter-twitterusername" name="Twitter-twitterusername" type="text" value="'.$twitterusername.'" />
				<span style="font-size: 10px;">(for link)</span>
				</label></p>';
		echo '<p style="text-align:right;">
				<label for="Twitter-googleapikey">' . __('Google API Key:') . '
				<input style="width: 141px;" id="Twitter-googleapikey" name="Twitter-googleapikey" type="text" value="'.$googleapikey.'" />
				<span style="font-size: 10px;">(optional)</span>
				</label></p>';
		echo '<input type="hidden" id="Twitter-submit" name="Twitter-submit" value="1" />';
	}


	// Register widget for use
	register_sidebar_widget(array('Reliable Twitter', 'widgets'), 'widget_reliabletwitter');

	// Register settings for use, 325x400 pixel form
	register_widget_control(array('Reliable Twitter', 'widgets'), 'widget_reliabletwitter_control', 325, 400);
}

// Run code and init
add_action('widgets_init', 'widget_reliabletwitter_init');

?>
