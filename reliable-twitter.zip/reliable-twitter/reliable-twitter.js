google.load("feeds", "1", {"nocss" : true});

if (reliable_twitter_target) reliable_twitter_target = ' target="' + reliable_twitter_target + '"';

function initialize() {
	var feedReturn = "";
	var feed = new google.feeds.Feed("http://twitter.com/statuses/user_timeline/" + reliable_twitter_id + ".rss");
	feed.setNumEntries(reliable_twitter_show);
	feed.load(function(result) {
	if (!result.error) {
		var username = result.feed.title.substring(10);
		if (reliable_twitter_show >= result.feed.entries.length) reliable_twitter_show = result.feed.entries.length;
		for (var i = 0; i < reliable_twitter_show; i++) {
			var entry = result.feed.entries[i];
			if (entry != undefined) {
				var tweetcontents = entry.title.substring(username.length + 2) + " ";
				var created_at = entry.publishedDate;
				tweetcontents = tweetcontents.parseURL().parseUsername().parseHashtag();
				feedReturn += "<li>";
				feedReturn += "<span>" + tweetcontents + "</span>";
				feedReturn += "<a style=\"font-size:85%\" href=\"http://twitter.com/"+username+"\"" + reliable_twitter_target + " class=\"twitterdatelink\">" + relative_time(created_at) + "</a>";
				feedReturn += "</li>\n";
			}
		}
		document.getElementById("twitter_update_list").innerHTML = feedReturn;
	}});
}

google.setOnLoadCallback(initialize);

String.prototype.parseURL = function() {
	return this.replace(/[A-Za-z]+:\/\/[A-Za-z0-9-_]+\.[A-Za-z0-9-_:%&\?\/.=]+/g, function(url) {
		return '<a href="' + url + '"' + reliable_twitter_target + '>' + url + '</a>';
	});
};
String.prototype.parseUsername = function() {
	return this.replace(/[@]+[A-Za-z0-9-_]+/g, function(u) {
		var username = u.replace("@","")
		return '<a href="http://twitter.com/' + username + '"' + reliable_twitter_target + '>' + u + '</a>';
	});
};
String.prototype.parseHashtag = function() {
	return this.replace(/[#]+[A-Za-z0-9-_]+/g, function(t) {
		var tag = t.replace("#","%23")
		return '<a href="http://search.twitter.com/search?q=' + tag + '"' + reliable_twitter_target + '>' + t + '</a>';
	});
};

function relative_time(time_value) {
   var parsed_date = Date.parse(time_value);

   var relative_to = (arguments.length > 1) ? arguments[1] : new Date();
   var delta = parseInt((relative_to.getTime() - parsed_date) / 1000);

   if(delta < 60) {
       return 'less than a minute ago';
   } else if(delta < 120) {
       return 'about a minute ago';
   } else if(delta < (45*60)) {
       return (parseInt(delta / 60)).toString() + ' minutes ago';
   } else if(delta < (90*60)) {
           return 'about an hour ago';
       } else if(delta < (24*60*60)) {
       return 'about ' + (parseInt(delta / 3600)).toString() + ' hours ago';
   } else if(delta < (48*60*60)) {
       return '1 day ago';
   } else {
       return (parseInt(delta / 86400)).toString() + ' days ago';
   }
}